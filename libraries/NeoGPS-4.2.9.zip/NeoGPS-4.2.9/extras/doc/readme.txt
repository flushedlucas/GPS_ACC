These .MD files are in github markdown format.  They are intended to be read on the github website, as linked from the top repository page.
